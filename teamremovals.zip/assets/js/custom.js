// sticky header
var stickyEl = $('.me_sticky');
$(window).on('scroll load', function() {
    if ($(window).scrollTop() >= 80) {
        $('.me_sticky').addClass('fixed_header');
    } else {
        $('.me_sticky').removeClass('fixed_header');
    }
})


$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    autoplay:true,
    autoplayTimeout:3000,
    autoplayHoverPause:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1100:{
            items:2
        }
    }
})

$('#testimonials').owlCarousel({
    stagePadding: 0,
    loop: true,
    margin: 10,
    nav: true,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1300: {
            items: 2
        }
    }
})