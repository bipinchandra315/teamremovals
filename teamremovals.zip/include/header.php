<header>

    <div class="main-header me_sticky ">
        <div class="container d-flex desktop-header py-3">
            <div class="header-logo">
                <a title="" href="<?php echo $link; ?>"><img src="assets/images/logo.png" class="img-fluid logo" alt=""></a>
            </div>
            <nav class="d-flex align-items-center justify-content-between w-100">
                <div>
                </div>
                <div class="top-head">
                    <ul class="d-flex dropdown-list align-items-center">
                        <li class="mx-3 active menu-list">
                            <a title="" href="index.php" class="link-list">Home
                            </a>
                        </li>
                        <li class="mx-2 after-cls menu-list">
                            <a title="" href="<?php echo $link; ?>" class="link-list" title="">About<i class="fas fa-chevron-down px-2"
                                    aria-hidden="true"></i></a>
                            <ul class="dropdown">
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>about-us.php">
                                        About Teamremovals</a>
                                </li>
                               
                            </ul>
                        </li>
                        <li class="mx-2 after-cls menu-list">
                            <a title="" href="<?php echo $link; ?>services/" class="link-list" title="">Services<i class="fas fa-chevron-down px-2"
                                    aria-hidden="true"></i></a>
                            <ul class="dropdown">
                                
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/house-removalists-australia.php">
                                House Removalists</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/furniture-removalist.php">
                                Furniture Removalists</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/interstate-removalist.php">
                                Interstate Removalists</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/man-with-a-van.php">
                                Man With A Van </a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/office-removalists.php">
                                Office Removalists</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/cleaning-services.php">
                                Cleaning Services </a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/packing-services-australia.php">
                                Packing And Unpacking</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/removalists-services.php">
                                Removalists Services</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/piano-removalist.php">
                                Piano Removalists</a>
                                </li>
                                <li class="menu-item"><a title="" class="menu-link" title="" href="<?php echo $link; ?>services/pool-table-removalist.php">
                                Pool Table Removalists</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/last-minute-removals.php">
                                Last Minute Removals</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/small-removals.php">
                                Small Removals</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/single-item-removals.php">
                                Single Item Removals</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/fridge-removalists.php">
                                Fridge Removalists</a>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>services/bathtub-removalists.php">
                                Bathtub Removalists</a>
                                </li>
                                
                               
                            </ul>
                        </li>
                        <li class="mx-3 menu-list">
                            <a title="" href="<?php echo $link; ?>" class="link-list">Blogs
                            </a>
                        </li>
                        <li class="mx-3 menu-list">
                            <a title="" href="contact-us.php" class="link-list">Contact Us
                            </a>
                        </li>
                        <li>
                            <div class="left-round">
                                <a title="" href="<?php echo $link; ?>"> <i class="fa-solid fa-phone"></i> (222) 422-925</a>
                            </div>
                        </li>
                        <li>
                            <button class="right-round" data-bs-toggle="modal" title="" href="#exampleModalToggle" role="button">
                              Get A Quote
                            </button>
                        </li>

                    </ul>

                </div>
            </nav>
        </div>
        <!-- mobile header -->
        <!-- <div class="header-mobile">
            <div class="header">
                <div class="container">
                    <nav class="navbar">

                        <a title="" href="/ayurveda" title="">
                            <img src="assets/images/logo.png" alt="logo" class="logo-img bg-theme">
                        </a>

                        <button type="button" class="burger" id="burger">
                            <span class="burger-line"></span>
                            <span class="burger-line"></span>
                            <span class="burger-line"></span>
                        </button>


                        <span class="overlay" id="overlay"></span>
                        <div class="menu" id="menu">
                            <ul class="menu-block ">
                                <li class="menu-item"><a class="menu-link" title="" href="/"><strong>Home</strong> </a></li>

                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">
                                        Home page</a></li>
                                <li class="menu-item">
                                    <button onclick="myFunction1()" class="dropbtn">Home page</button>
                                    <ul id="myDropdown1" class="dropdown-content">
                                        <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">
                                                <i class="fal fa-long-arrow-alt-right px-2"></i>Home page</a>
                                        </li>
                                        <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">
                                                <i class="fal fa-long-arrow-alt-right px-2"></i> Home page</a>
                                        </li>
                                        <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">
                                                <i class="fal fa-long-arrow-alt-right px-2"></i>Home page</a>
                                        </li>
                                        <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">
                                                <i class="fal fa-long-arrow-alt-right px-2"></i>Home page</a>
                                        </li>
                                        <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">
                                                <i class="fal fa-long-arrow-alt-right px-2"></i>Home page</a>
                                        </li>
                                        <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">
                                                <i class="fal fa-long-arrow-alt-right px-2"></i>Home page</a>
                                        </li>
                                        <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">
                                                <i class="fal fa-long-arrow-alt-right px-2"></i>Home page</a>
                                        </li>

                                    </ul>
                                </li>
                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">Home page</a></li>

                                <li class="menu-item"><a class="menu-link" title="" href="<?php echo $link; ?>">Home page</a></li>

                                <li class="menu-item"><a class="menu-link menu-apnt" title="" href="<?php echo $link; ?>" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal3">Home page </a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>

        </div> -->
    </div>
</header>