    <script src="<?php echo $link; ?>assets/js/jquery.min.js"></script>
    <script src="<?php echo $link; ?>assets/js/owl.carousel.min.js"></script>
    <script src="<?php echo $link; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $link; ?>assets/js/custom.js"></script>