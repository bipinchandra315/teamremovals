<div class="fixed-form">
                                    <form class="px-0">

                                        <div class="form-body">

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control my-2" placeholder="Name*"
                                                        aria-label="Name">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control my-2"
                                                        placeholder="Phone Number*" aria-label="Last name">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control my-2" placeholder="Email*"
                                                        aria-label="Last name">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <textarea class="form-control my-2" id="exampleFormControlTextarea1"
                                                        rows="2" placeholder="Message"></textarea>
                                                </div>
                                            </div>
                                            <div class="book-appointment d-flex mt-2 justify-content-center">
                                                <a href="<?php echo $link; ?>" class="btn3" title="">
                                                    <span>Send Enquiry</span> </a>
                                            </div>
                                        </div>

                                    </form>
                                </div>